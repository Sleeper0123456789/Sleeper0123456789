-- DocTrade doctor registration workflow.
-- Run this AFTER 001_initial_schema.sql.

-- Seed the initial specialty list. Administrators can extend this later.
insert into public.specialties (name)
values
  ('General Practice'),
  ('Cardiology'),
  ('Dermatology'),
  ('Gynaecology'),
  ('Neurology'),
  ('Obstetrics'),
  ('Oncology'),
  ('Ophthalmology'),
  ('Orthopaedics'),
  ('Paediatrics'),
  ('Psychiatry'),
  ('Psychology'),
  ('Radiology'),
  ('Urology'),
  ('Dentistry'),
  ('Other')
on conflict (name) do nothing;

-- A doctor can associate their own professional record with an active specialty.
create policy "Professionals can add their own specialties"
on public.professional_specialties
for insert to authenticated
with check (
  exists (
    select 1
    from public.healthcare_professionals hp
    join public.specialties s on s.id = specialty_id
    where hp.id = professional_id
      and hp.user_id = (select auth.uid())
      and s.is_active = true
  )
);

create policy "Professionals can remove their own specialties"
on public.professional_specialties
for delete to authenticated
using (
  exists (
    select 1
    from public.healthcare_professionals hp
    where hp.id = professional_id
      and hp.user_id = (select auth.uid())
  )
);

-- Controlled self-service role elevation:
-- this function can ONLY change the caller's own profile to healthcare_professional
-- and creates a pending professional record. It cannot create an administrator.
create or replace function public.register_doctor_profile(
  p_full_name text,
  p_phone text,
  p_professional_type text,
  p_professional_title text,
  p_bio text,
  p_specialty_id uuid,
  p_practice_name text,
  p_street_address text,
  p_suburb text,
  p_city text,
  p_province text,
  p_postal_code text,
  p_in_person boolean,
  p_online boolean
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_professional_id uuid;
begin
  if v_user_id is null then
    raise exception 'You must be logged in to register as a doctor';
  end if;

  if nullif(trim(p_full_name), '') is null
     or nullif(trim(p_professional_type), '') is null
     or p_specialty_id is null
     or nullif(trim(p_practice_name), '') is null
     or nullif(trim(p_street_address), '') is null
     or nullif(trim(p_city), '') is null
     or nullif(trim(p_province), '') is null then
    raise exception 'Please complete all required doctor registration fields';
  end if;

  if not p_in_person and not p_online then
    raise exception 'Select at least one consultation type';
  end if;

  if not exists (
    select 1 from public.specialties
    where id = p_specialty_id and is_active = true
  ) then
    raise exception 'Selected specialty is not available';
  end if;

  if exists (
    select 1 from public.healthcare_professionals
    where user_id = v_user_id
  ) then
    raise exception 'A doctor profile already exists for this account';
  end if;

  update public.profiles
  set
    role = 'healthcare_professional',
    full_name = trim(p_full_name),
    phone = nullif(trim(p_phone), ''),
    updated_at = now()
  where id = v_user_id;

  if not found then
    raise exception 'User profile was not found';
  end if;

  insert into public.healthcare_professionals (
    user_id,
    professional_type,
    professional_title,
    bio,
    verification_status,
    profile_completion
  )
  values (
    v_user_id,
    trim(p_professional_type),
    nullif(trim(p_professional_title), ''),
    nullif(trim(p_bio), ''),
    'pending',
    60
  )
  returning id into v_professional_id;

  insert into public.professional_specialties (professional_id, specialty_id)
  values (v_professional_id, p_specialty_id);

  insert into public.practice_locations (
    professional_id,
    practice_name,
    street_address,
    suburb,
    city,
    province,
    postal_code
  )
  values (
    v_professional_id,
    trim(p_practice_name),
    trim(p_street_address),
    nullif(trim(p_suburb), ''),
    trim(p_city),
    trim(p_province),
    nullif(trim(p_postal_code), '')
  );

  return v_professional_id;
end;
$$;

revoke all on function public.register_doctor_profile(
  text,text,text,text,text,uuid,text,text,text,text,text,text,boolean,boolean
) from public, anon;

grant execute on function public.register_doctor_profile(
  text,text,text,text,text,uuid,text,text,text,text,text,text,boolean,boolean
) to authenticated;
