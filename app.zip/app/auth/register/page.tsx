import Link from "next/link";
import { RegisterForm } from "@/components/auth/register-form";

export default function RegisterPage() {
  return (
    <main style={{ maxWidth: 520, margin: "0 auto", padding: 40 }}>
      <h1>Create your DocTrade account</h1>
      <RegisterForm />
      <p style={{ marginTop: 24 }}>
        Are you a doctor or healthcare professional?{" "}
        <Link href="/register/doctor">Register as a Doctor</Link>
      </p>
    </main>
  );
}
