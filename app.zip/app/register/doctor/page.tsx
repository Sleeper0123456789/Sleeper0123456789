import Link from "next/link";
import { DoctorRegistrationForm } from "@/components/doctor/doctor-registration-form";

export default function DoctorRegistrationPage() {
  return (
    <main className="min-h-screen bg-slate-50 px-4 py-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <Link href="/" className="text-sm font-medium text-blue-700 hover:underline">
            ← Back to DocTrade
          </Link>
          <h1 className="mt-4 text-3xl font-bold tracking-tight text-slate-900">
            Register as a Doctor
          </h1>
          <p className="mt-2 text-slate-600">
            Create your professional DocTrade profile. Your profile starts as pending verification.
          </p>
        </div>
        <DoctorRegistrationForm />
      </div>
    </main>
  );
}
