import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <main style={{ maxWidth: 1000, margin: "0 auto", padding: 40 }}>
      <h1>DocTrade</h1>
      <p>Find the Right Doctor. Book With Confidence.</p>
      <p>South African healthcare professional discovery and appointment platform.</p>

      <nav style={{ display: "flex", gap: 16, marginTop: 24, flexWrap: "wrap" }}>
        <Link href="/auth/login">Login</Link>
        <Link href="/auth/register">Register</Link>
        <Link href="/register/doctor">Register as a Doctor</Link>
        <Link href="/dashboard">Dashboard</Link>
      </nav>

      {user && <p style={{ marginTop: 24 }}>Signed in as {user.email}</p>}
    </main>
  );
}
