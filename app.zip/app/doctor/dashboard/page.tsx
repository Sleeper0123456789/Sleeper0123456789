import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function DoctorDashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect(`/auth/login?next=${encodeURIComponent("/doctor/dashboard")}`);

  const { data: profile } = await supabase
    .from("healthcare_professionals")
    .select("professional_type, professional_title, bio, verification_status, profile_completion")
    .eq("user_id", user.id)
    .maybeSingle();

  if (!profile) redirect("/register/doctor");

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-10">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl font-bold text-slate-900">Doctor Dashboard</h1>
        <p className="mt-2 text-slate-600">Welcome, {user.email}</p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Today", "0"],
            ["This week", "0"],
            ["This month", "0"],
            ["This year", "0"],
          ].map(([label, value]) => (
            <div key={label} className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
              <p className="text-sm text-slate-500">{label}</p>
              <p className="mt-2 text-3xl font-bold text-slate-900">{value}</p>
              <p className="mt-1 text-xs text-slate-500">Appointments</p>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <h2 className="text-xl font-semibold">Professional profile</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <p><strong>Type:</strong> {profile.professional_type}</p>
            <p><strong>Title:</strong> {profile.professional_title ?? "Not set"}</p>
            <p><strong>Status:</strong> {profile.verification_status}</p>
            <p><strong>Profile completion:</strong> {profile.profile_completion}%</p>
          </div>
          <p className="mt-4 text-slate-600">{profile.bio ?? "No description added yet."}</p>
        </div>
      </div>
    </main>
  );
}
