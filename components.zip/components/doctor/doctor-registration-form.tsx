"use client";

import { FormEvent, useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

type Specialty = { id: string; name: string };

export function DoctorRegistrationForm() {
  const router = useRouter();
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [loadingSpecialties, setLoadingSpecialties] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [professionalTitle, setProfessionalTitle] = useState("Dr");
  const [professionalType, setProfessionalType] = useState("Medical Doctor");
  const [bio, setBio] = useState("");
  const [specialtyId, setSpecialtyId] = useState("");

  const [practiceName, setPracticeName] = useState("");
  const [streetAddress, setStreetAddress] = useState("");
  const [suburb, setSuburb] = useState("");
  const [city, setCity] = useState("");
  const [province, setProvince] = useState("");
  const [postalCode, setPostalCode] = useState("");

  const [inPerson, setInPerson] = useState(true);
  const [online, setOnline] = useState(false);

  useEffect(() => {
    async function loadSpecialties() {
      const supabase = createClient();
      const { data, error } = await supabase
        .from("specialties")
        .select("id,name")
        .eq("is_active", true)
        .order("name");

      if (error) {
        setError(error.message);
      } else {
        setSpecialties(data ?? []);
      }
      setLoadingSpecialties(false);
    }

    loadSpecialties();
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setMessage("");
    setLoading(true);

    if (!inPerson && !online) {
      setError("Select at least one consultation type.");
      setLoading(false);
      return;
    }

    const supabase = createClient();
    const { data: authData } = await supabase.auth.getUser();
    let user = authData.user;

    if (!user) {
      if (!email.trim() || password.length < 8) {
        setError("Enter an email address and a password of at least 8 characters.");
        setLoading(false);
        return;
      }

      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: { data: { full_name: fullName.trim() } },
      });

      if (signUpError) {
        setError(signUpError.message);
        setLoading(false);
        return;
      }

      if (!signUpData.user) {
        setError("We could not create your account. Please try again.");
        setLoading(false);
        return;
      }

      if (!signUpData.session) {
        setMessage("Your account was created. Check your email to confirm your address, then log in and complete the doctor registration.");
        setLoading(false);
        return;
      }

      user = signUpData.user;
    }

    const { data, error: rpcError } = await supabase.rpc("register_doctor_profile", {
      p_full_name: fullName.trim(),
      p_phone: phone.trim() || null,
      p_professional_type: professionalType.trim(),
      p_professional_title: professionalTitle.trim() || null,
      p_bio: bio.trim() || null,
      p_specialty_id: specialtyId,
      p_practice_name: practiceName.trim(),
      p_street_address: streetAddress.trim(),
      p_suburb: suburb.trim() || null,
      p_city: city.trim(),
      p_province: province,
      p_postal_code: postalCode.trim() || null,
      p_in_person: inPerson,
      p_online: online,
    });

    if (rpcError) {
      setError(rpcError.message);
      setLoading(false);
      return;
    }

    setMessage("Your doctor profile has been submitted for verification.");
    setLoading(false);

    if (data) {
      setTimeout(() => router.push("/doctor/dashboard"), 700);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-8 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
      <section>
        <h2 className="text-xl font-semibold text-slate-900">Account</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Field label="Email address" value={email} onChange={setEmail} type="email" required />
          <Field label="Password" value={password} onChange={setPassword} type="password" required />
        </div>
        <p className="mt-2 text-sm text-slate-500">
          If you already have a DocTrade account, log in first and then complete this form.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-slate-900">Professional information</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Field label="Full name" value={fullName} onChange={setFullName} required />
          <Field label="Phone number" value={phone} onChange={setPhone} type="tel" />
          <Field label="Professional title" value={professionalTitle} onChange={setProfessionalTitle} />
          <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700">Professional type</span>
            <select value={professionalType} onChange={(e) => setProfessionalType(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2.5">
              <option>Medical Doctor</option>
              <option>General Practitioner</option>
              <option>Specialist</option>
              <option>Other Healthcare Professional</option>
            </select>
          </label>
          <label className="block md:col-span-2">
            <span className="mb-1 block text-sm font-medium text-slate-700">Specialty</span>
            <select required value={specialtyId} onChange={(e) => setSpecialtyId(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2.5">
              <option value="">Select a specialty</option>
              {specialties.map((specialty) => (
                <option key={specialty.id} value={specialty.id}>{specialty.name}</option>
              ))}
            </select>
            {loadingSpecialties && <span className="mt-1 block text-sm text-slate-500">Loading specialties...</span>}
          </label>
          <label className="block md:col-span-2">
            <span className="mb-1 block text-sm font-medium text-slate-700">Professional description</span>
            <textarea required value={bio} onChange={(e) => setBio(e.target.value)} rows={5}
              className="w-full rounded-lg border border-slate-300 px-3 py-2.5"
              placeholder="Describe your practice, experience and services." />
          </label>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-slate-900">Practice location</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Field label="Practice name" value={practiceName} onChange={setPracticeName} required />
          <Field label="Street address" value={streetAddress} onChange={setStreetAddress} required />
          <Field label="Suburb" value={suburb} onChange={setSuburb} />
          <Field label="City / Town" value={city} onChange={setCity} required />
          <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700">Province</span>
            <select required value={province} onChange={(e) => setProvince(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2.5">
              <option value="">Select province</option>
              {["Eastern Cape","Free State","Gauteng","KwaZulu-Natal","Limpopo","Mpumalanga","Northern Cape","North West","Western Cape"].map((p) =>
                <option key={p}>{p}</option>
              )}
            </select>
          </label>
          <Field label="Postal code" value={postalCode} onChange={setPostalCode} />
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-slate-900">Consultation options</h2>
        <div className="mt-4 flex flex-wrap gap-4">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={inPerson} onChange={(e) => setInPerson(e.target.checked)} />
            <span>In-person consultations</span>
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={online} onChange={(e) => setOnline(e.target.checked)} />
            <span>Online consultations</span>
          </label>
        </div>
      </section>

      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
      {message && <p role="status" className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700">{message}</p>}

      <button disabled={loading || loadingSpecialties} type="submit"
        className="w-full rounded-lg bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800 disabled:cursor-not-allowed disabled:opacity-60">
        {loading ? "Submitting profile..." : "Submit Doctor Registration"}
      </button>
    </form>
  );
}

function Field({
  label, value, onChange, type = "text", required = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-slate-700">{label}</span>
      <input required={required} type={type} value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-300 px-3 py-2.5" />
    </label>
  );
}
